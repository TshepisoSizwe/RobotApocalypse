package interviewProject.robotApocalypse.service.impl;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SurvivorServiceImplTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getAllSurvivors() {
    }

    @Test
    void getSurvivorById() {
    }

    @Test
    void saveSurvivor() {
    }

    @Test
    void updateSurvivor() {
    }

    @Test
    void flagSurvivorAsInfected() {
    }

    @Test
    void getSurvivorByInfectionStatus() {
    }

    @Test
    void calculateInfectionPercentage() {
    }

    @Test
    void calculateNonInfectedPercentage() {
    }
}