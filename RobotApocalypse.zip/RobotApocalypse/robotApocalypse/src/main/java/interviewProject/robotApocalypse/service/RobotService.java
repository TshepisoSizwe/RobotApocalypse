package interviewProject.robotApocalypse.service;

public interface RobotService {

    public String fetchAndDisplaySortedRobots(String robotUrl);

}
